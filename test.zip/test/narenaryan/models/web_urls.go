package models

import (
	"database/sql"
	"log"

	_ "github.com/lib/pq"
)

func InitDB() (*sql.DB, error) {
	var err error
	db, err := sql.Open("postgres",
		"postgres://userdb:cr7@localhost/userdb?sslmode=disable")
	if err != nil {
		return nil, err
	} else {
		stmt, err := db.Prepare(`CREATE TABLE userdb(ID SERIAL PRIMARY KEY, URL TEXT NOT NULL);`)
		if err != nil {
			log.Println(err)
			return nil, err
		}
		result, err := stmt.Exec()
		log.Println(result)
		if err != nil {
			log.Println(err)
			return nil, err
		}
		return db, err
	}
}
