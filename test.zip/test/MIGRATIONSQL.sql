create table class(name text, surname text);
insert into class(name,surname) values('Otabek','Nosirov');